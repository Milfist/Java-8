Simple example of using static methods in interfaces.
Before Java8, it was necessary to create classes that supported the interfaces since methods could not be implemented in the interfaces.