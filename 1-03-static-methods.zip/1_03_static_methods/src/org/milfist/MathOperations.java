package org.milfist;

public interface MathOperations {

	static Double pow(Double a, Double b) {	
		return Math.pow(a, b);
	}
	
}
